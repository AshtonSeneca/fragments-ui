# Deployment Guide - fragments-ui

## Step-by-Step Deployment Instructions

### Phase 1: Local Testing

#### 1. Install Dependencies

```powershell
npm install
```

#### 2. Start Development Server

```powershell
npm start
```

- Open browser to http://localhost:1234
- Test login functionality
- Test creating fragments
- Test viewing fragments list

### Phase 2: Build and Test Docker Image Locally

#### 1. Build the Docker Image

```powershell
# Build the image
docker build -t fragments-ui:latest .

# Verify the image was created
docker images | Select-String "fragments-ui"
```

#### 2. Run the Container Locally

```powershell
# Run on port 8080
docker run -d -p 8080:80 --name fragments-ui fragments-ui:latest

# Check if container is running
docker ps

# View container logs
docker logs fragments-ui

# Test health check
docker inspect --format='{{json .State.Health}}' fragments-ui
```

#### 3. Test the Containerized Application

- Open browser to http://localhost:8080
- Verify all functionality works
- Test authentication
- Test fragment creation
- Test fragment listing

#### 4. Stop and Remove Container (for cleanup)

```powershell
docker stop fragments-ui
docker rm fragments-ui
```

### Phase 3: Push to Docker Hub

#### 1. Login to Docker Hub

```powershell
docker login
# Enter your Docker Hub username and password
```

#### 2. Tag the Image

```powershell
# Replace <your-username> with your Docker Hub username
docker tag fragments-ui:latest <your-username>/fragments-ui:latest

# You can also add version tags
docker tag fragments-ui:latest <your-username>/fragments-ui:v1.0
```

#### 3. Push to Docker Hub

```powershell
# Push latest tag
docker push <your-username>/fragments-ui:latest

# Push version tag (if created)
docker push <your-username>/fragments-ui:v1.0
```

#### 4. Verify on Docker Hub

- Go to https://hub.docker.com/
- Navigate to your repositories
- Confirm fragments-ui is listed and public
- Check the image details and tags

### Phase 4: Pull and Run from Docker Hub (Optional Testing)

```powershell
# Remove local images (to test pulling from Docker Hub)
docker rmi fragments-ui:latest
docker rmi <your-username>/fragments-ui:latest

# Pull from Docker Hub
docker pull <your-username>/fragments-ui:latest

# Run the pulled image
docker run -d -p 8080:80 --name fragments-ui <your-username>/fragments-ui:latest

# Test to confirm it works
```

### Phase 5: Configuration for Different Environments

#### Development (localhost)

Default configuration in code:
- API_URL: http://localhost:8080 or your EC2 URL
- OAUTH_SIGN_IN_REDIRECT_URL: http://localhost:1234

#### Production with Custom API URL

```powershell
# Run with environment variable
docker run -d -p 8080:80 `
  -e API_URL=http://your-production-api.com:8080 `
  --name fragments-ui `
  <your-username>/fragments-ui:latest
```

**Note**: Since we're using a static build with Parcel, environment variables must be set at BUILD time, not runtime. To change the API URL:

1. Update the API_URL in src/api.js before building
2. Or use Parcel's .env file support

### Docker Commands Reference

#### Building

```powershell
# Basic build
docker build -t fragments-ui:latest .

# Build with no cache
docker build --no-cache -t fragments-ui:latest .

# Build with specific tag
docker build -t fragments-ui:v1.0 .
```

#### Running

```powershell
# Run detached with port mapping
docker run -d -p 8080:80 --name fragments-ui fragments-ui:latest

# Run with logs visible (foreground)
docker run -p 8080:80 --name fragments-ui fragments-ui:latest

# Run with custom name
docker run -d -p 8080:80 --name my-fragments-ui fragments-ui:latest

# Run with restart policy
docker run -d -p 8080:80 --restart unless-stopped --name fragments-ui fragments-ui:latest
```

#### Inspecting

```powershell
# View container logs
docker logs fragments-ui

# Follow logs in real-time
docker logs -f fragments-ui

# Inspect container details
docker inspect fragments-ui

# Check health status
docker inspect --format='{{.State.Health.Status}}' fragments-ui

# View container stats
docker stats fragments-ui
```

#### Cleaning Up

```powershell
# Stop container
docker stop fragments-ui

# Remove container
docker rm fragments-ui

# Remove image
docker rmi fragments-ui:latest

# Clean up all stopped containers
docker container prune

# Clean up unused images
docker image prune

# Clean up everything (use with caution!)
docker system prune -a
```

### Troubleshooting

#### Build Fails

**Error**: `npm ci` fails
```powershell
# Solution: Clear npm cache and try again
docker build --no-cache -t fragments-ui:latest .
```

**Error**: `npm run build` fails
```powershell
# Solution: Check that Parcel is in dependencies
# Verify package.json has correct build script
```

#### Container Won't Start

```powershell
# Check logs for errors
docker logs fragments-ui

# Check if port 8080 is already in use
netstat -ano | findstr :8080

# Try a different port
docker run -d -p 9090:80 --name fragments-ui fragments-ui:latest
```

#### Cannot Access Application

**Issue**: Cannot access http://localhost:8080

```powershell
# Verify container is running
docker ps

# Check port mappings
docker port fragments-ui

# Check nginx logs
docker logs fragments-ui

# Test with curl
curl http://localhost:8080
```

#### Health Check Failing

```powershell
# Check health status
docker inspect --format='{{json .State.Health}}' fragments-ui | ConvertFrom-Json

# Check if nginx is responding
docker exec fragments-ui wget -q -O- http://localhost/
```

### Best Practices Checklist

- ✅ Multi-stage build reduces final image size
- ✅ .dockerignore excludes unnecessary files
- ✅ Alpine Linux base for smaller footprint
- ✅ Dependencies installed before copying source (layer caching)
- ✅ Health check configured
- ✅ nginx optimized for static content
- ✅ Gzip compression enabled
- ✅ Proper cache headers for static assets
- ✅ Security: non-root user (nginx default)
- ✅ No sensitive data in image

### Image Size Optimization

Expected image sizes:
- Build stage: ~500-600 MB (includes Node.js and dependencies)
- Final production stage: ~25-35 MB (only nginx + static files)

To verify:
```powershell
docker images fragments-ui
```

### Next Steps for Production

For a real production deployment, consider:

1. **CI/CD Pipeline**: Automate building and pushing (GitHub Actions)
2. **Image Scanning**: Use tools like Trivy to scan for vulnerabilities
3. **Orchestration**: Use Kubernetes or Docker Swarm for scaling
4. **Load Balancing**: Deploy multiple instances behind a load balancer
5. **HTTPS**: Use a reverse proxy (like Traefik) for SSL/TLS
6. **Monitoring**: Add logging and monitoring (Prometheus, Grafana)
7. **Environment Variables**: Use secrets management for sensitive config

### For Your Assignment

Remember to include in your technical report:

1. Screenshot of Docker Hub repository (showing public access)
2. Screenshot of `docker images` output showing your image
3. Screenshot of `docker ps` showing running container
4. Screenshot of application working via Docker (localhost:8080)
5. Evidence of multi-stage build (mention in report)
6. Evidence of nginx serving the static site

### Useful Docker Hub Links

- Your repository: `https://hub.docker.com/r/<your-username>/fragments-ui`
- Docker Hub docs: https://docs.docker.com/docker-hub/
- Best practices: https://docs.docker.com/develop/dev-best-practices/

Good luck! 🐳
