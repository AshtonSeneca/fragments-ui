# Assignment 2 Technical Report - Quick Reference Guide

## Docker Commands for Testing

### Building the Docker Image

```powershell
# Build the image locally
docker build -t fragments-ui:latest .

# Build with Docker Hub tag
docker build -t <your-dockerhub-username>/fragments-ui:latest .
```

### Running the Container Locally

```powershell
# Run on port 8080
docker run -d -p 8080:80 --name fragments-ui fragments-ui:latest

# View logs
docker logs fragments-ui

# Stop the container
docker stop fragments-ui

# Remove the container
docker rm fragments-ui
```

### Pushing to Docker Hub

```powershell
# Login to Docker Hub
docker login

# Push the image
docker push <your-dockerhub-username>/fragments-ui:latest
```

## Testing Checklist for Technical Report

### Screenshots to Capture

1. **Cognito Authentication**
   - [ ] Login page/button
   - [ ] Cognito Hosted UI login screen
   - [ ] Successfully authenticated (showing username)

2. **View Existing Fragments with Metadata**
   - [ ] Click "Get All Fragments" button
   - [ ] Display showing fragment list with ALL metadata:
     - Fragment ID
     - Type
     - Size
     - Created timestamp
     - Updated timestamp
     - Owner ID
   - [ ] Make sure expand=1 is visible in the result

3. **Create JSON Fragment**
   - [ ] Select "JSON (application/json)" from dropdown
   - [ ] Enter valid JSON in textarea, example:
     ```json
     {
       "title": "My Test Fragment",
       "description": "Testing JSON creation",
       "timestamp": "2025-12-01T00:00:00Z"
     }
     ```
   - [ ] Click "Create Fragment"
   - [ ] Capture result showing:
     - Status: 201 Created
     - **Location header** (IMPORTANT!)
     - Fragment metadata

4. **Create Markdown Fragment**
   - [ ] Select "Markdown (text/markdown)" from dropdown
   - [ ] Enter Markdown content, example:
     ```markdown
     # Test Markdown Fragment
     
     This is a **test** markdown fragment.
     
     - Item 1
     - Item 2
     - Item 3
     ```
   - [ ] Click "Create Fragment"
   - [ ] Capture result showing Location header

5. **Updated Fragments List**
   - [ ] Show the fragments list automatically refreshed with new fragments
   - [ ] All metadata visible for each fragment

## Sample Test Data

### JSON Fragment Examples

```json
{
  "name": "Test User",
  "email": "test@example.com",
  "role": "admin"
}
```

```json
{
  "course": "CCP555",
  "assignment": 2,
  "completed": true,
  "technologies": ["Docker", "nginx", "Parcel", "AWS"]
}
```

### Markdown Fragment Examples

```markdown
# Assignment 2 Test

This is a test **markdown** fragment for Assignment 2.

## Features Implemented
- User authentication
- Fragment creation
- Metadata display
```

```markdown
# Docker Best Practices

1. Multi-stage builds
2. Alpine Linux images
3. Layer caching
4. .dockerignore file
```

### Plain Text Examples

```
This is a simple plain text fragment for testing.
```

```
Hello from fragments-ui!
Testing the create functionality.
```

## Important Notes for Report

1. **Location Header**: Make sure at least one screenshot clearly shows the Location header in the response

2. **Expanded Metadata**: The fragments list must show expand=1 was used (full metadata, not just IDs)

3. **Authentication Flow**: Show the complete flow from login to viewing fragments

4. **Docker Evidence**: 
   - Show Docker image on Docker Hub (public repository)
   - Show container running locally
   - Show connecting to EC2-hosted API

5. **Response Format**: Each creation should show:
   - HTTP Status (201)
   - Location header
   - Fragment metadata (id, type, size, created, updated, ownerId)

## Common Issues and Solutions

### Issue: No Location Header Showing
**Solution**: Check your API server implementation - it should return the Location header on POST

### Issue: Fragments Not Loading
**Solution**: 
- Check API_URL in src/api.js
- Verify EC2 instance is running
- Check CORS configuration on API server

### Issue: Authentication Fails
**Solution**:
- Verify Cognito Pool ID and Client ID
- Check redirect URL matches Cognito configuration
- Clear browser cache and try again

### Issue: JSON Validation Error
**Solution**: Make sure JSON is properly formatted (use a JSON validator)

### Issue: Docker Build Fails
**Solution**:
- Check that all dependencies are in package.json
- Ensure src/ directory exists
- Try: docker system prune -a (then rebuild)

## Technical Report Structure Reminder

1. **Introduction**
   - Overview of updates since Assignment 1
   - Brief description of fragments-ui purpose

2. **GitHub Repository Links**
   - fragments (API server)
   - fragments-ui (this project)

3. **Docker Hub Links**
   - fragments image
   - fragments-ui image

4. **GitHub Actions CI**
   - Link to successful workflow run
   - Shows tests passing

5. **EC2 Screenshots**
   - API server running as Docker container
   - Health check response

6. **fragments-ui Screenshots** (6 required)
   - Authentication + existing fragments
   - Create JSON fragment
   - Create Markdown fragment
   - At least one showing Location header clearly

7. **Code Coverage**
   - Screenshot of npm run coverage
   - Should show >80% coverage

8. **Conclusion**
   - Summary of implementation
   - Known issues (if any)
   - Plans for Assignment 3

## Quick Test Procedure

1. Start your EC2 API server
2. Run fragments-ui locally: `npm start`
3. Open http://localhost:1234
4. Click Login → authenticate with Cognito
5. Click "Get All Fragments" → capture screenshot
6. Create JSON fragment → capture screenshot (show Location!)
7. Create Markdown fragment → capture screenshot
8. Show refreshed fragments list
9. Build Docker image
10. Push to Docker Hub
11. Pull and run Docker container
12. Test the containerized version

Good luck with your assignment! 🚀
